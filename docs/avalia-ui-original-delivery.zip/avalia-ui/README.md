# Avalia UI

The Avalia.rock component library — *latex & fetish meets neon-retro*, dark-mode only.
Built as **Astro components + plain CSS + one vanilla-JS file**, ready to drop into the
Astro + Directus site.

> The visual catalogue (`Component Library.html` in the project root) is the **living
> documentation / showroom**. *This* folder (`avalia-ui/`) is the actual library the
> website consumes.

---

## What's in the box

```
avalia-ui/
├── avalia-ui.js                 # all client interactions (framework-agnostic, import once)
├── README.md
└── src/
    ├── styles/
    │   ├── tokens.css           # design tokens (CSS variables: colors, type, spacing, glow)
    │   └── components.css       # every component style + layout utilities (.av-*)
    ├── components/
    │   ├── Icon.astro           # inline SVG icon set
    │   ├── Button.astro         # primary / secondary / ghost · sizes · external
    │   ├── Badge.astro          # category / new / updated / featured
    │   ├── Field.astro          # input / textarea / select (one component)
    │   ├── Section.astro        # max-width section + header + "view all"
    │   ├── ProductCard.astro    # ← Directus `Producten`
    │   ├── UpdateCard.astro     # ← Directus `Updates`
    │   ├── PromoCard.astro      # ← Directus `Promos` (also the homepage hero)
    │   ├── TopTask.astro        # the 3 homepage "top task" blocks
    │   ├── Navbar.astro         # desktop nav + mobile slide-out (scroll-aware)
    │   ├── Footer.astro         # ← Directus `Site Instellingen`
    │   ├── CategoryFilter.astro # filter pills (emits `filter:change`)
    │   ├── Accordion.astro      # + AccordionItem.astro (FAQ / features)
    │   ├── Gallery.astro        # product-detail thumbnail grid
    │   ├── Lightbox.astro       # global lightbox singleton
    │   ├── AgeGate.astro        # 18+ overlay (localStorage-remembered)
    │   └── GlobalOverlays.astro # bundles AgeGate + Lightbox + toast stack
    ├── layouts/
    │   └── BaseLayout.astro     # example layout wiring everything together
    ├── pages/
    │   └── index.astro          # example homepage, composed per the wireframe
    └── lib/
        └── directus.ts          # tiny asset-URL + fetch helpers
```

---

## Install (Astro)

1. **Copy `avalia-ui/` into your Astro project** (e.g. to `src/lib/avalia-ui/` or keep at root).
   The `.astro` files only depend on each other and the two CSS files — no npm package needed.

2. **Load fonts + styles + script once**, in your base layout. `BaseLayout.astro` already
   does this; the essence is:

   ```astro
   ---
   import 'avalia-ui/src/styles/tokens.css';
   import 'avalia-ui/src/styles/components.css';
   import 'avalia-ui/avalia-ui.js';     // interactions — import ONCE
   ---
   <link href="https://fonts.googleapis.com/css2?family=Lobster&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
   ```

3. **Mount the global singletons once** (age gate, lightbox, toasts):

   ```astro
   import GlobalOverlays from 'avalia-ui/src/components/GlobalOverlays.astro';
   <GlobalOverlays brand="Avalia" leaveUrl="https://www.google.com" />
   ```

That's it — start using components.

---

## Using components

```astro
---
import ProductCard from 'avalia-ui/src/components/ProductCard.astro';
import Section from 'avalia-ui/src/components/Section.astro';
---
<Section eyebrow="Shop" title="Featured products" viewAllHref="/products">
  <div class="av-grid av-grid-3">
    <ProductCard name="Neon Harness" href="/products/neon-harness"
                 category="Harness" description="Glossy latex harness…"
                 image="/img/neon.jpg" isNew />
  </div>
</Section>
```

Every component's props are documented in a comment block at the top of its `.astro` file.

### Layout utilities (ship with `components.css`)
- `.av-container` — centered, max-width 1200px, responsive padding
- `.av-section` / `.av-section--tight` — vertical rhythm (80 / 48px)
- `.av-grid` + `.av-grid-2|3|4` — responsive grids (collapse to 2 then 1 column)
- `.av-reveal` — fade-up on scroll (driven by `avalia-ui.js`)

### Toasts (programmatic)
```js
AvaliaUI.toast({ type: 'success', title: 'Message sent', message: 'We'll be in touch.' });
// types: 'success' | 'info'
```

---

## How props map to your Directus content types

| Component | Directus collection | Prop ← field |
|---|---|---|
| `ProductCard` | **Producten** | `name←naam`, `href←/products/{slug}`, `category←categorie.naam`, `description←korte_beschrijving`, `image←afbeeldingen[0]`, `isNew←is_nieuw` |
| `UpdateCard` | **Updates** | `title←titel`, `href←/updates/{slug}`, `date←publicatiedatum`, `excerpt←excerpt`, `image←afbeelding` |
| `PromoCard` | **Promos** | `title←titel`, `description←beschrijving`, `image←afbeelding`, `ctaText←cta_tekst`, `ctaUrl←cta_url` |
| `Navbar` / `Footer` | **Site Instellingen** | `brand←site_naam`, `social←social_links` |
| `Accordion` | FAQ (over/about) | `items=[{question, answer}]` |
| `Gallery` | **Producten** | `images←afbeeldingen.map(directusAsset)` |

Resolve image fields with `directusAsset()` from `src/lib/directus.ts`.

```astro
---
import { getItems, directusAsset } from 'avalia-ui/src/lib/directus';
const products = await getItems('producten', {
  'filter[is_featured][_eq]': 'true',
  'fields': 'naam,slug,korte_beschrijving,is_nieuw,categorie.naam,afbeeldingen.directus_files_id',
  limit: '3'
});
---
{products.map((p) => (
  <ProductCard name={p.naam} href={`/products/${p.slug}`}
    category={p.categorie?.naam} description={p.korte_beschrijving}
    image={directusAsset(p.afbeeldingen?.[0]?.directus_files_id)} isNew={p.is_nieuw} />
))}
```

---

## Without Astro (plain HTML / other stacks)

You don't need Astro to use the look & behaviour:

1. `<link>` **`tokens.css`** then **`components.css`**, load the Lobster + Outfit fonts.
2. Add `<script src="avalia-ui.js"></script>` before `</body>`.
3. Copy the HTML markup for any component straight from `Component Library.html`
   (the catalogue) or from the `.astro` template body — the class names are identical.

For React/Vue/Svelte: the CSS + `avalia-ui.js` are framework-agnostic; wrap the same
markup in your own components, or render Astro components as islands.

---

## Notes
- **Dark-mode only** by design. All color comes from the tokens — re-skin by editing
  `tokens.css` (the accent gradient lives in `--accent-blue/-purple/-pink`).
- **Reduced motion** is respected automatically (`prefers-reduced-motion`).
- `avalia-ui.js` is **idempotent** and re-runs on `astro:page-load`, so it survives
  Astro View Transitions and island hydration.
- The age-gate decision is stored in `localStorage` under `avalia_age_ok`.
